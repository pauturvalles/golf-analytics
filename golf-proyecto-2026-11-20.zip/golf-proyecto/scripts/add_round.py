#!/usr/bin/env python3
"""Añade UNA ronda nueva de Shot Scope a `const DATA` del dashboard en castellano.

Entrada: raw/round_YYYY-MM-DD.json (ver MANUAL_OPERACIONES.md, sección 5), con
  - meta        : resumen de /api/rounds/slim
  - api_holes   : hoyos y golpes de /api/rounds/slim (columnas en shot_cols)
  - page_holes  : texto de la vista "Hole By Hole" (club corto, lie, distancia, restante, SG oficial)
  - club_names  : clubID -> nombre del API (solo los palos usados)

Salida (solo con --apply): reescribe `const DATA = {...};` del HTML y actualiza analysis/data.json.
Sin --apply solo valida y muestra el resumen (dry run).

Uso:
  python3 scripts/add_round.py raw/round_2026-11-20.json \
      --html dashboard/golf-analysis-es.html --data analysis/data.json \
      --short-name "Jávea" --hcp 11 [--tc] [--apply]

Reglas validadas contra las 41 rondas anteriores (513 hoyos): GIR = golpes antes del primer putt desde
el green <= par-2; GIR+1 = <= par-1; putts = golpes con lie Green; FIR del hoyo = FIR del golpe 1
(None en par 3); Stableford = max(0, 2 + par + sr - gross). Golpes recibidos (sr): SI <= hcp -> 1,
+1 si SI <= hcp-18 (hcp de 18 hoyos, sin dividir, también en rondas de 9; escala SI de 18 hoyos).
Para campos con SI local 1-9 (Altea, La Sella) hay que repartir el hcp a la mitad: NO soportado aquí
sin --local-si (ver manual, sección 8).

NUNCA ejecutar nada de esto contra los ficheros del dashboard público en inglés.
"""
import argparse
import json
import re
import sys
import unicodedata


def club_name(api_name):
    """'49 Degree Wedge' -> '49° Wedge'; '22 Degree Hybrid' -> '22° Hybrid'; el resto igual."""
    m = re.match(r"^(\d+) Degree (Wedge|Hybrid)$", api_name)
    return f"{m.group(1)}° {m.group(2)}" if m else api_name


def short_id(name):
    s = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Za-z0-9]", "", s.title())


def num(txt):
    return 0.0 if txt == "Holed" else float(txt)


def strokes_received(si, hcp, local_si=False):
    if local_si:  # SI local 1-9: el hcp de 18 se reparte a la mitad (.5 hacia arriba)
        hcp = (hcp + 1) // 2
        full = 9
    else:
        full = 18
    return (1 if si <= hcp else 0) + (1 if si <= hcp - full else 0)


def build(raw, short_name, hcp, tc, local_si, r_index):
    meta = raw["meta"]
    date = meta["startedDate"][:10]
    course = meta["courseName"]
    clubs = raw["club_names"]
    problems = []
    holes, shots = [], []
    sg_total = 0.0
    gross_total = net_total = stb_total = 0
    api_h, page_h = raw["api_holes"], raw["page_holes"]
    assert len(api_h) == len(page_h) == meta["playedHoles"], "nº de hoyos distinto entre API y página"
    for ah, ph in zip(api_h, page_h):
        n = ah["n"]
        assert ph["n"] == n
        cols = raw["shot_cols"]
        a_shots = [dict(zip(cols, s)) for s in ah["shots"]]
        assert len(a_shots) == len(ph["shots"]), f"hoyo {n}: nº de golpes distinto API/página"
        par, si, score = ah["par"], float(ah["si"]), ah["score"]
        rows = []
        for i, (a, p) in enumerate(zip(a_shots, ph["shots"])):
            club_short, lie, dist, rem, sg = p
            cl = club_name(clubs[str(a["clubID"])]) if a["strokeType"] != "Penalty" else None
            # coherencia API vs página
            if lie.lower() != a["lie"]:
                problems.append(f"hoyo {n} golpe {i+1}: lie página {lie} != API {a['lie']}")
            if abs(float(dist) - a["distance"]) > max(1.0, 0.02 * a["distance"]):
                problems.append(f"hoyo {n} golpe {i+1}: distancia página {dist} vs API {a['distance']:.1f}")
            flag = "lost_ball" if a["lostBall"] else ("penalty_drop" if a["waterHazard"] else ("positional" if a["positional"] else None))
            rows.append({
                "r": r_index, "h": n, "rc": course, "sn": a["shotNumber"],
                "et": "penalty" if a["strokeType"] == "Penalty" else "shot",
                "cl": cl, "lie": lie, "dist": num(dist), "rem": num(rem), "sg": sg, "flag": flag,
                "dtp": round(a["distanceToPin"], 2),
                "eo": round(a["edgeOffset"], 2), "vo": round(a["verticalOffset"], 2),
                "ho": round(a["horizontalOffset"], 2), "fo": round(a["fairwayOffset"], 2),
                "fir": bool(a["fir"]),
            })
        # sumas de SG
        s_sum = round(sum(r["sg"] for r in rows), 2)
        if abs(s_sum - ph["sg"]) > 0.011:
            problems.append(f"hoyo {n}: suma de SG de los golpes {s_sum} != SG del hoyo {ph['sg']}")
        sg_total += ph["sg"]
        k = next((i for i, r in enumerate(rows) if r["lie"] == "Green"), None)
        sr = strokes_received(si, hcp, local_si)
        stb = max(0, 2 + par + sr - score)
        gross_total += score
        net_total += score - sr
        stb_total += stb
        n_rows_shot = sum(1 for r in rows if r["et"] == "shot")
        if n_rows_shot + sum(1 for r in rows if r["et"] == "penalty") != score:
            problems.append(f"hoyo {n}: golpes+penalizaciones != score {score}")
        holes.append({
            "r": r_index, "h": n, "rc": course, "rh": n, "p": par, "si": si, "sr": sr,
            "pu": sum(1 for r in rows if r["lie"] == "Green" and r["et"] == "shot"),
            "g": score, "ns": score - sr,
            "fir": None if par == 3 else int(bool(a_shots[0]["fir"])),
            "gir": int(k is not None and k <= par - 2), "gp1": int(k is not None and k <= par - 1),
            "pen": sum(1 for r in rows if r["et"] == "penalty"),
            "lost": sum(1 for r in rows if r["flag"] == "lost_ball"),
            "dm": round(a_shots[0]["distanceToPin"], 1), "stb": stb,
        })
        shots.extend(rows)
    sg_total = round(sg_total, 2)
    if abs(sg_total - raw["page_round_sg_front9"]) > 0.011:
        problems.append(f"SG de la ronda {sg_total} != {raw['page_round_sg_front9']} (Front 9 de la página)")
    if gross_total != meta["totalShots"]:
        problems.append(f"gross {gross_total} != totalShots API {meta['totalShots']}")
    put = sum(h["pu"] for h in holes)  # putts = golpes con lie Green (criterio del dashboard)
    if put != raw["page_putts_total"]:
        problems.append(f"putts (lie Green) {put} != putts de la página {raw['page_putts_total']}")
    putter_strokes = sum(1 for r in shots if r["cl"] == "Putter")
    if putter_strokes != meta["putts"]:  # el API cuenta todos los golpes con putter, incluso desde fuera del green
        problems.append(f"golpes con Putter {putter_strokes} != putts API {meta['putts']}")
    rnd = {
        "id": f"{date}_{short_id(short_name)}", "d": date, "y": int(date[:4]), "c": short_name,
        "rc": [course], "t": meta["tees"], "sg_total": sg_total, "hcp": hcp, "gr": gross_total,
        "net": net_total, "stb": stb_total, "nh": meta["playedHoles"], "tc": tc,
    }
    return rnd, holes, shots, problems


DATA_RE = re.compile(r"const DATA = (\{.*?\});\n", re.S)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw")
    ap.add_argument("--html", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--short-name", required=True)
    ap.add_argument("--hcp", type=int, required=True, help="hcp de campo de 18 hoyos que Pau mete en Shot Scope (positivo)")
    ap.add_argument("--tc", action="store_true", help="ronda de torneo")
    ap.add_argument("--local-si", action="store_true", help="campo con SI local 1-9 (Altea, La Sella)")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()

    raw = json.load(open(a.raw, encoding="utf8"))
    html = open(a.html, encoding="utf8").read()
    m = DATA_RE.search(html)
    assert m, "no se encontró `const DATA = {...};` en el HTML"
    data = json.loads(m.group(1))
    # guarda de formato: el DATA existente debe reserializarse byte a byte igual
    ser = lambda d: json.dumps(d, ensure_ascii=False, separators=(",", ":"))
    assert ser(data) == m.group(1), "la reserialización de DATA no es idéntica; abortar (no tocar el HTML)"

    date = raw["meta"]["startedDate"][:10]
    if any(r["d"] == date and r["c"] == a.short_name for r in data["rounds"]):
        sys.exit(f"ya existe una ronda de {a.short_name} el {date}")
    if data["rounds"] and date < data["rounds"][-1]["d"]:
        sys.exit("la ronda no es posterior a la última de DATA (las rondas van ordenadas por fecha)")

    r_index = len(data["rounds"])
    rnd, holes, shots, problems = build(raw, a.short_name, a.hcp, a.tc, a.local_si, r_index)
    print(json.dumps(rnd, ensure_ascii=False))
    print(f"hoyos={len(holes)} golpes={len(shots)} stb={rnd['stb']} gross={rnd['gr']} net={rnd['net']} sg={rnd['sg_total']}")
    if problems:
        print("PROBLEMAS:")
        for p in problems:
            print(" -", p)
        sys.exit(1)
    print("validación OK")
    if not a.apply:
        print("(dry run: nada escrito)")
        return
    data["rounds"].append(rnd)
    data["holes"].extend(holes)
    data["shots"].extend(shots)
    new_html = html[:m.start(1)] + ser(data) + html[m.end(1):]
    open(a.html, "w", encoding="utf8").write(new_html)
    open(a.data, "w", encoding="utf8").write(ser(data))
    print(f"escrito: {a.html} y {a.data} ({len(data['rounds'])} rondas, {len(data['holes'])} hoyos, {len(data['shots'])} golpes)")


if __name__ == "__main__":
    main()
