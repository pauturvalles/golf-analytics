# scripts/

- `add_round.py` — añade una ronda nueva (a partir de `raw/round_YYYY-MM-DD.json`) a `const DATA` del dashboard en castellano. Dry run por defecto; `--apply` escribe el HTML y `analysis/data.json`. Ver `MANUAL_OPERACIONES.md`, sección 5. Reglas de derivación (GIR, putts, FIR, Stableford...) validadas contra las 41 rondas anteriores.

**Estado (20-nov-2026):** pipeline mínimo reconstruido (solo añadir una ronda). Los scripts originales (`rebuild_all.py`, `process_round.py`, `build_dashboard_data.py`, etc.) se perdieron el 10-oct-2026 y no se han reconstruido.
