# Prompt: extract your Shot Scope data into a clean dataset

A reusable prompt for a Claude session that has browser access (Claude in Chrome, or the built-in browser in the desktop app). Open Shot Scope in that browser and **log in yourself first**. Never paste your password or tokens into the chat; the session reuses the login you already have.

Copy everything inside the block below into Claude.

---

```
I want to build a personal golf analytics project from my Shot Scope data.
I'm already logged in to https://dashboard.shotscope.com in the browser you
control. Do NOT ask for or type my password; work only through the session
that is already open, and only READ data. Never click anything that edits,
signs off or submits anything on my account.

GOAL
Produce three clean CSVs (rounds.csv, holes.csv, shots.csv) covering every
round on my account, plus one raw JSON per round so the pipeline can be
re-run later without touching Shot Scope again.

STEP 1 - Fetch the data the SPA already loads
- From a tab on dashboard.shotscope.com, run in the page context:
    const r = await fetch('/api/rounds/slim', {credentials: 'include'});
    const data = await r.json();
  (Use the browser JS tool; this uses my existing session cookies.)
- First inspect the shape: list the top-level keys, the number of rounds, and
  one full round -> hole -> shot object. Show me the field names before
  building anything.
- Useful fields I expect per shot: club, club id / model, distance, distance
  to pin (before the shot), lie before/after, start/end GPS, vertical and
  horizontal offset from the target line, fairway/edge offset, left/right
  miss flags, and explicit flags for lost ball, penalty/positional drop and
  water hazard. Per hole: par, stroke index, score, putts, pin/turn GPS.
  Per round: date, course, tees, handicap used, and the official totals.
- Penalty strokes come with shotNumber = 0 for every penalty on a hole.
  Do not key shots by shotNumber alone; filter strokeType != 'Penalty' (or
  key by displayed shot number and keep penalties separately), or you will
  get collisions.
- Hole distance = the distanceToPin of the FIRST shot of each hole.

STEP 2 - Get the official strokes-gained numbers (the API does NOT have them)
- /api/rounds/slim has no per-shot strokes gained. The official per-shot SG
  only appears in the rendered round view ("Hole By Hole" in the round
  detail page): each shot card has text like
    Shot/1/Club/D/Lie/Tee/Distance/229 m/Remaining/155 m/SG/0.07
- For each round, navigate hole by hole (read-only), read the page text
  (prefer get-page-text / read-page over screenshots) and parse club, lie,
  distance, remaining and SG per shot. Keep Shot Scope's own SG values
  verbatim; do not recompute them with your own model.
- Validate every round: the sum of per-shot SG must equal Shot Scope's SG
  per hole, and the hole sums must equal the round total. Report any round
  or hole that does not reconcile instead of silently fixing it.
- Do the rounds in small batches and save raw JSON per round to disk after
  each one, so a dropped session never loses work.

STEP 3 - Build the CSVs
- rounds.csv: one row per round (date, course, tees, holes played, gross,
  net, stableford, course handicap, total SG).
- holes.csv: one row per hole (par, stroke index, score, putts, FIR, GIR,
  penalties, distance in m, hole SG, pin lat/lng).
- shots.csv: one row per shot with the fields from Step 1 plus Shot Scope's
  own SG per shot, and a normalised event_type (shot / penalty).
- Derive putts from lie == 'Green' per hole rather than from any scraped
  summary table.
- Set an explicit flag per shot (lost_ball, penalty_drop, none) from the
  API's own flags; do not leave it blank. Anything downstream that counts
  blow-ups or penalties depends on it.

STEP 4 - Strokes-gained categories
- Classify each shot into Tee / Approach / Short Game / Putting using the
  same rules Shot Scope uses: first shot of a hole = Tee; a non-tee shot
  that starts more than 45.72 m (50 yd) from the hole = Approach; closer
  than that = Short Game; a putt counts as Putting only when played from the
  green (a putt from off the green is Short Game).
- Check that my four category totals reproduce Shot Scope's own category
  numbers for a couple of rounds before trusting them.

GOTCHAS - please handle these explicitly
- 9-hole rounds: Shot Scope's overall / "vs benchmark" view DOUBLES the
  numbers to compare against 18 holes. Store the raw 9-hole values and tell
  me which rounds are 9-hole; never use the doubled figure as the round SG.
- Course/slope rating is NOT in the export. Only the tee name is. If I want
  WHS-style differentials I will supply ratings myself.
- If I edit a shot's distance in Shot Scope after a round, the API can lag
  or I may have edited a different hole than I remember. Re-fetch and compare
  before assuming a bug.
- Shot Scope's benchmark can be set to different handicap levels (e.g. "vs
  10 HCP" vs "vs scratch"). Ask me which benchmark I use and make sure the
  SG values you read come from that one.
- Some shots have no distance (lost ball / water drops). Keep them, mark the
  distance as empty, and exclude them from distance-based stats.

OUTPUT
1. First, a short plan and the schema you found (Step 1 inspection), then
   wait for my OK.
2. After building, a validation report: rounds processed, rounds that
   reconcile, and every discrepancy found.
3. Save everything in a project folder: raw/round_YYYY-MM-DD.json, plus the
   three CSVs, plus the script(s) that produced them so I can re-run it for
   new rounds.
```

---

## Notes for you

- **No credentials ever go into the chat.** Log in manually in the browser first; the prompt only reads data through that open session.
- `/api/rounds/slim` is an internal endpoint of the Shot Scope web app, not a documented public API. It can change without notice, so the "inspect the shape first" step matters.
- The official per-shot strokes gained is the one thing you can't get from that endpoint, which is why Step 2 reads the rendered round view. It's the slow part (one page per hole), so batch it and save as you go.
- For new rounds later, you only need to repeat Steps 1-3 for the rounds that aren't in your raw folder yet.
- Check Shot Scope's terms of use before sharing or republishing any of the data. This prompt only pulls your own account's data for personal analysis.
