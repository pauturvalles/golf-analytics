# Manual de operaciones: análisis de golf de Pau (Shot Scope)

Última actualización: 10-oct-2026. Este manual consolida cómo se trabaja en el proyecto, por qué, y los errores ya descubiertos. El detalle histórico de cada cambio vive en el doc del proyecto `claude/golf-analisis-rendimiento.md` (rondas de cambios 1-76). **Cada vez que cambie algo de esto, se entrega a Pau un ZIP actualizado para su GitHub** (ver sección 9).

## 1. Estado actual del código (importante)

El entorno de trabajo de Claude es efímero. Entre el 27-sep y el 7-oct-2026 se reclamó y se **perdieron**: los scripts Python del pipeline (`rebuild_all.py`, `process_round.py`, `build_dashboard_data.py`, `build_round.py`, `build_new_round.py`, `rebuild_combined*.py`), los JSON crudos por ronda (`raw/round_YYYY-MM-DD.json`), los CSV y el código fuente separado del dashboard (`dashboard-es.js`) y del dashboard público en inglés.

Lo que **sí se conserva**:

- `golf-analysis-es.html`: el dashboard completo (HTML + CSS + todo el JS en un único `<script>`) con los datos procesados embebidos en `const DATA = {rounds, holes, shots}` (41 rondas, 513 hoyos, 2.620 golpes, con SG oficial por golpe). **Desde el 10-oct-2026 este HTML es la fuente de verdad**: se edita directamente (ya no hay paso de reconstrucción que sobrescriba el `<script>`).
- El doc del proyecto (decisiones, metodología, bugs y arreglos) y la memoria.
- Los scripts de análisis en `analysis/` (comparación del esperado, ver sección 7).

Pendiente: reconstruir un pipeline Python mínimo para **añadir rondas nuevas** a `DATA` (ver sección 5). Guardar esos scripts en el ZIP en cuanto existan.

## 2. Reglas permanentes

1. Solo se modifica el dashboard privado en castellano (`golf-analysis-es.html`). El dashboard privado en inglés (`golf-analysis.html`/`dashboard.js`) queda intacto y el **público en inglés (`puntos-de-fuga-en.html`/`dashboard-en.js`) NUNCA se toca**. Si el pipeline se reconstruye: nunca ejecutar un rebuild que escriba el JSON o los ficheros del público (el JSON intermedio se compartía entre privado y público; riesgo ya identificado).
2. El HTML entregado con SendUserFile **no debe usar `localStorage`/`sessionStorage`** en código nuevo. (Existe un uso heredado, solo para recordar columnas ocultas, siempre dentro de `try/catch`: `initColumnToggle`. No ampliarlo.)
3. Shot Scope: solo **lectura**, usando la sesión que Pau ya tiene abierta en el navegador. Nunca pedir ni escribir su contraseña; nunca firmar/enviar/editar nada en su cuenta.
4. Conversación con Pau en castellano. UI del dashboard en castellano con la jerga golfística en inglés (SG, GIR, FIR, Approach, Short Game, Putting, Expected, Vs Expected, Blow-up, etc.). Entregables externos que pida (p. ej. el prompt para un compañero) en inglés.
5. Nunca usar un borrado amplio tipo `rm -f /tmp/*.py`.
6. Si aparece un campo nuevo sin Valor de Campo/Slope en `COURSE_RATINGS`, avisar a Pau y pedirle solo esos dos números (no hace falta el Excel completo).
7. Cada cambio se verifica con Playwright (6 pestañas, escritorio 1400px y móvil 390px) y se registra en el changelog del proyecto.

## 3. Estructura de `DATA` (en el HTML)

- `rounds[]`: `id, d (fecha), y, c (campo corto), rc (array de recorridos reales), t (tee), sg_total, hcp, gr, net, stb, nh (9|18), tc (torneo)`.
- `holes[]`: `r (índice de ronda), h (nº de hoyo en la ronda), rc, rh (hoyo físico real), p (par), si, sr (golpes recibidos), pu (putts), g (gross), ns (net), fir, gir, gp1 (GIR+1), pen, lost, dm (distancia m), stb`.
- `shots[]`: `r, h, rc, sn (nº de golpe), et (evento), cl (palo), lie, dist, rem (restante), sg, flag (lost_ball|penalty_drop|''), dtp (distancia a bandera GPS), eo, vo, ho, fo (offsets), fir`.
- `hcp` de cada ronda = hándicap de campo **de 18 hoyos** que Pau introduce en Shot Scope (también en rondas de 9). Nunca ponerlo a la mitad.
- Cada hoyo/ronda se identifica por `r|h`. El hoyo físico es `rc|rh` (La Sella combina recorridos: cada uno cuenta por separado).

## 4. Funciones clave del dashboard (por si hay que tocarlas)

- Expected: `ensureHoleModel`, `holeModelOf`, `buildExpectedScorePools`, `computeHoleExpectedAgg` (devuelve `expected` = media de todas las visitas y `expByRound` = esperado de cada visita, clave `ronda|hoyo`), `HOLE_AGG_FULL_MAP` (ver sección 6). **El detalle de ronda (`renderRoundHoleTable`) debe usar `expByRound` de ESA ronda, nunca `expected`.**
- Detalle de ronda: `renderRoundHoleTable` (Vs Histórico **excluye la propia ronda**; usar `agg.avgScore` diluía el diferencial a la mitad, bug corregido).
- SG por categoría: `classifyShot` + `computeRoundSgCategories`. Errores: `classifyRoundErrors` (4 cubos excluyentes: lost_ball, penalty_drop, 3-putt, otros SG≤-1.0) y `computeRoundExtraStats` (suma plana SG≤-1.0 → `cataSg`, `cataCount`). **Por eso "SG catastrófico" puede dar -5.8 en un sitio y -2.46 en otro: dos definiciones, no un bug.**
- Hándicap WHS: `courseRatingForRound`, `scoreDifferentialForRound`, `courseLoopDifferential`, `nineHoleDifferential`, `nineHalfFromHoles`, tablas `COURSE_RATINGS` y `COURSE_NINE_RATINGS`.
- KPIs: `KPI_DEFS` (15 entradas; `wedgeAttackFinishSg` es secundaria de `wedgeAttackStrokes`, sin tarjeta propia), `kpiCalc`, `kpiFmtValue`, `kpiLastRoundValue`, `renderKpiSection`, `renderKpiSummaryTable` (tabla resumen ordenada por mejora; usa un `Set` de claves secundarias).
- Tooltips de gráficos: `clampTooltipLeft`/`clampTooltipTop` (los contenedores tienen `overflow:hidden`; el tooltip es `position:absolute` y se limita su `max-width`).

## 5. Procedimiento para una ronda nueva

(El pipeline Python original se perdió; esto es lo que hacía y lo que hay que reproducir.)

1. Pau deja abierto el navegador en `https://dashboard.shotscope.com` con su sesión iniciada. El sandbox de Claude tiene red restringida por lista de dominios: las llamadas a Shot Scope se hacen con `fetch()` **dentro de la pestaña del navegador** (se ejecuta en el ordenador de Pau).
2. Extraer `/api/rounds/slim` (endpoint interno, sin documentar, con cookie de sesión; puede cambiar sin aviso). Inspeccionar primero la forma. Guardar un JSON por ronda: `raw/round_YYYY-MM-DD.json`.
   Nota de arquitectura (del doc del proyecto): la fuente principal de club/lie/distancia/SG por golpe era el **scraping del DOM** de Shot Scope; `/api/rounds/slim` era la fuente complementaria (GPS, offsets de golpe, flags `lostBall`/`waterHazard`/`positional`, `clubTagAssignments`, `distanceToPin`, par/SI por hoyo y tee). Migrar todo a la API no aportaba nada nuevo, salvo simplificar.
3. El **SG oficial por golpe no está en la API**: solo aparece en el texto de la vista "Hole By Hole" (`Shot/1/Club/D/Lie/Tee/Distance/229 m/Remaining/155 m/SG/0.07`). Leer hoyo a hoyo con get-page-text, mantener los valores verbatim y validar que la suma de golpes = SG del hoyo y la suma de hoyos = SG de la ronda.
4. Construir `rounds/holes/shots` y añadirlos a `DATA` (índice de ronda nuevo = al final; las rondas van ordenadas por fecha).
5. Pedir a Pau Valor de Campo/Slope si el campo/tee es nuevo (sección 8).
6. Verificar con Playwright, actualizar el changelog, entregar HTML + ZIP.

## 6. Metodología del "Expected" (rediseñada el 10-oct-2026)

Expected de un hoyo = shrinkage `weight*local + (1-weight)*par_mean` (`weight = n/(n+10)`), con `local` = media de otros hoyos con el mismo par y la misma dificultad (SI), `par_mean` = media de otros hoyos con ese par, **ambos excluyendo el propio hoyo físico**. Se calcula por instancia y se promedia.

Dos correcciones nuevas:

1. **SI en escala común 1-9.** Altea y cada recorrido de La Sella usan SI local 1-9; Jávea, Puig Campana y Oliva Nova en 9 hoyos usan 1,3,5…17 (o 2,4…18); las rondas de 18 usan 1-18. Rondas de 9: se reordena el SI entre los 9 hoyos jugados. Rondas de 18: `ceil(SI/2)`. La columna SI de las tablas sigue mostrando el SI original.
2. **Offset por hándicap de campo de la ronda: `hcp/18` golpes por hoyo.** Cada gross del pool se ajusta restándole el offset de su ronda, y al esperado de una instancia se le suma el de su propia ronda. Combina dificultad del campo y nivel de Pau en ese momento.

Por qué (medido con los 63 hoyos con ≥3 visitas): el residual medio por campo correlacionaba +0.71 con la dificultad oficial del campo (CR/Slope); y el residual medio por semestre derivaba de +0.30 (1S-2025) a -0.16 (2S-2026) mientras el hcp bajaba de ~23 a ~13, es decir ~0.45 golpes/hoyo de sesgo temporal. Con el `hcp` de la ronda como offset la deriva queda dentro de ±0.14. Los rankings cambian poco (2-3 hoyos de 10 en cada lista; Spearman ≈0.9): la mejora es de justicia, no de resultado dramático.

Limitaciones conocidas: el `hcp` es el índice oficial (escalonado y con retraso: ≈20.4 de feb a nov-2025, ≈15 desde dic-2025, ≈12.5 desde abr-2026); un poco de circularidad leve (el índice sale de las mismas tarjetas); sobrecorrige ligeramente (-0.14 / +0.11 por semestre). Recent Avg y Trend siguen en bruto, por lo que Vs Expected ya no refleja "he mejorado en general" sino "contra lo esperable para mi nivel de ese día".

## 7. Experimentos hechos (no repetir sin motivo)

- **Ajuste por elevación** en las dos últimas rondas (Altea, Font del Llop): efecto agregado <1 %, ruido por palo → no compensa construirlo.
- **Comparación de variantes del esperado** (`analysis/exp.js`, `analysis/exp2.js`; leen `analysis/data.json`, el `DATA` extraído del HTML): V0 actual, V1 SI común, V2 SI común + offset de campo (HI 12), V3 SI común + offset `hcp` de la ronda (la implementada). La réplica V0 coincidió con el dashboard anterior (diferencia 0 en los 63 hoyos). Hoy `exp.js` valida la réplica V3 contra la función real del dashboard (extraída del HTML por marcadores de texto) y sirve de **test de regresión**: `node analysis/exp.js` debe imprimir `max |diff| vsExpected = 0.00e+0`; si no, algo ha cambiado en `buildExpectedScorePools`/`computeHoleExpectedAgg`.
- **Escalabilidad / web con login de Shot Scope**: la parte del dashboard escala (función del lado cliente de los CSV); la extracción no (endpoint interno con cookie, SG oficial solo por scraping hoyo a hoyo, ratings manuales). No se encontró API pública ni programa de partners; los T&C solo cubren tienda/sitio y no mencionan scraping. Pau descartó la idea. Mejor opción si se retomara: extensión de navegador local, nunca guardar credenciales en servidor.

## 8. Errores y particularidades descubiertos (lecciones)

**Datos / importación**

- Penalizaciones: Shot Scope pone `shotNumber = 0` en cada penalización de un hoyo → no indexar por `shotNumber`; filtrar `strokeType != 'Penalty'`. `shot_extra` debe indexarse por el **número de golpe mostrado**, no por posición secuencial (bug que desalineaba los golpes tras un drop; apareció en 3 rondas, ya corregido, con guarda de regresión `shot_extra_key_mismatches`).
- Flags explícitos por golpe: un golpe a agua lleva `penalty_drop`; bola perdida `lost_ball`; la fila sintética de la penalización queda con `flag:''`. Sin el flag, el golpe aún cuenta como catastrófico (SG≤-1.0) pero no en la tarjeta de penalizaciones (guarda `shot_flag_mismatches`).
- Clasificación de categoría SG: si no hay posición previa conocida en el hoyo, usar la `distanceToPin` GPS (`distance_to_pin`) antes que la estimación distancia+resto. Umbral Approach/Short Game 45,72 m (50 yd); un putt es Putting solo si se juega desde el green.
- Benchmark: nuestro SG corresponde al desglose "vs 10 HCP" de Shot Scope, no al "Strokes Gained Breakdown" que compara con la media móvil de las últimas 10 rondas (dos desgloses distintos en su pantalla de resumen).
- Rondas de 9 hoyos: Shot Scope duplica los números en su vista de resumen para comparar con 18. Guardamos los valores de 9 reales y nunca usamos el duplicado como SG de ronda. Shot Scope nunca fusiona dos vueltas de 9 del mismo día en una ronda de 18.
- FIR: usar el flag a nivel de golpe (`fir_shot`) como fuente preferente; el del hoyo solo como fallback (nunca en par 3).
- Los tees Ida/Vuelta de Altea: Shot Scope numera siempre los hoyos 1-9, así que la mitad jugada se detecta por el **patrón de par**, no por el número de hoyo (`nineHalfFromHoles`).
- Si Pau edita la distancia de un golpe tras la ronda, re-extraer en caliente y comparar antes de suponer un bug (y confirmar el número de hoyo: una vez era el 13, no el 14).

**Hándicap / ratings**

- Course Rating y Slope **no** vienen de Shot Scope: `COURSE_RATINGS` es una tabla mantenida a mano desde la Federación/Excel de Pau (12 campos + 3 combinaciones de La Sella). Rondas de 9: se dobla contra el rating de 18, salvo Altea (Ida 34.7/125, Vuelta 35.4/129, folleto RFEG 2017; el total web actual 70.8/130 no tiene desglose de 9).
- Resultado ajustado: tope por hoyo Net Double Bogey = par + 2 + golpes recibidos. Para campos con SI local 1-9 (Altea, La Sella) el hcp de 18 se reparte a la mitad (redondeando .5 hacia arriba) sobre la escala 1-9.
- "Nivel jugado" = media simple de todos los diferenciales de la ventana (no el índice oficial, que usa las N más bajas + ajuste). Sin PCC ni topes soft/hard cap, a propósito.
- Mestral solo (35.1/126, doblado a 70.2) se añadió para aislar el diferencial de cada visita a Mestral en rondas combinadas.

**Dashboard / front-end**

- Vs Expected del detalle de ronda: tras introducir el offset por hándicap, `agg.expected` pasó a promediar visitas con hándicaps de épocas distintas; usarlo contra el gross de una sola ronda inflaba el esperado (~+0.30 golpes/hoyo en Font del Llop 26-sep-2026: total -6.85 → -1.35 al corregir). Regla general: cualquier comparación de UNA ronda contra el esperado debe usar el esperado con el hándicap de esa ronda.

- Los tooltips se recortaban por el `overflow:hidden` de `.chart-wrap`/`.kpi-chart-wrap`: se limita con `clampTooltipLeft/Top` y `max-width`.
- En Playwright, el error `net::ERR_TUNNEL_CONNECTION_FAILED` es benigno (sin red externa) y se ignora. Pestañas: `data-tab` = overview, detailed, rounds, holes, clubs, courses. Para probar tooltips hay que hacer hover sobre la marca real (rect) y con scroll al elemento, no a ciegas.
- Filtro de la tabla resumen de KPIs: usar un `Set` de `secondaryKey` (el filtro `!def.secondaryKey` salía al revés).
- Open-Elevation devuelve coordenadas a 6 decimales: casar por vecino más próximo, no por clave exacta.
- WebFetch rechaza URLs adivinadas (PROVENANCE_REQUIRED): buscar primero para obtener URLs reales.

## 9. Protocolo de respaldo (acordado con Pau el 10-oct-2026)

- El entorno de Claude se reclama tras un periodo de inactividad; el código solo vivía allí. Por eso: **tras cualquier cambio** al manual, a las particularidades/errores, a scripts Python/JS o al dashboard, Claude entrega a Pau un ZIP (`golf-proyecto-AAAA-MM-DD.zip`) para subir a su GitHub. El repo debe ser **privado** (contiene sus datos de Shot Scope).
- Estructura del ZIP: `README.md`, `MANUAL_OPERACIONES.md`, `CHANGELOG.md` (entrada de esa tanda), `dashboard/golf-analysis-es.html`, `analysis/` (scripts y `data.json`), `scripts/` (Python del pipeline cuando exista), `prompts/` (prompt de extracción en inglés).
- Además se guarda la copia canónica del manual en el Project (`claude/golf-manual-operaciones.md`) y el changelog en `claude/golf-analisis-rendimiento.md`.
- Si Pau abre una sesión nueva y faltan ficheros: pedirle el último ZIP/HTML (el HTML basta para retomar el dashboard y los análisis; el pipeline Python se reconstruye).
