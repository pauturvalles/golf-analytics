# Análisis de golf (Shot Scope) — copia de respaldo

Respaldo del proyecto de análisis de rendimiento de golf de Pau. **Mantener este repositorio PRIVADO**: contiene sus datos personales de Shot Scope.

## Contenido

- `MANUAL_OPERACIONES.md` — reglas permanentes, estructura de datos, funciones clave, procedimiento para rondas nuevas, metodología, errores y lecciones, y protocolo de respaldo. **Empezar por aquí.**
- `CHANGELOG.md` — entradas de la última tanda de cambios. El historial completo está en `docs/golf-analisis-rendimiento.md`.
- `dashboard/golf-analysis-es.html` — el dashboard completo (HTML + CSS + JS, con los datos embebidos en `const DATA`). Es la **fuente de verdad** desde el 10-oct-2026: se abre directamente en el navegador y se edita directamente.
- `analysis/` — scripts de análisis (Node): comparación de variantes del "Expected" (`exp.js`, `exp2.js`) y verificación con Playwright (`verify_expected_v2.js`). `data.json` es el `DATA` extraído del HTML.
- `docs/golf-analisis-rendimiento.md` — copia del doc del proyecto de Claude (metodología y changelog completo, rondas 1-76).
- `prompts/shotscope_extraction_prompt.md` — prompt (en inglés) para extraer datos de Shot Scope con una sesión de Claude con navegador.
- `scripts/` — Python del pipeline; pendiente de reconstruir (ver su README).

## Cómo ejecutar el análisis

```
cd analysis
node exp.js        # test de regresión (debe imprimir diff 0.00e+0) + comparación de variantes V0/V1/V2
node exp2.js       # V3 (la implementada) + deriva temporal
```
`verify_expected_v2.js` necesita `npm i playwright` y un Chromium (en el entorno de Claude: `/opt/pw-browsers/chromium`).

## Retomar con Claude en una sesión nueva

Pasarle este ZIP (o al menos el HTML y `MANUAL_OPERACIONES.md`). Con el HTML basta para seguir con el dashboard y los análisis; el pipeline Python para añadir rondas nuevas hay que reconstruirlo.

Estado a 10-oct-2026: 41 rondas (2025-02 a 2026-09), 513 hoyos, 2.620 golpes.
