# scripts/

Aquí irán los scripts Python del pipeline (importar una ronda nueva de Shot Scope -> añadirla a `DATA` del dashboard).

**Estado (10-oct-2026): pendiente de reconstruir.** Los originales (`rebuild_all.py`, `process_round.py`, `build_dashboard_data.py`, `build_round.py`, `build_new_round.py`, `rebuild_combined*.py`) se perdieron al reclamarse el entorno de trabajo de Claude. Ver `MANUAL_OPERACIONES.md`, secciones 1 y 5.
