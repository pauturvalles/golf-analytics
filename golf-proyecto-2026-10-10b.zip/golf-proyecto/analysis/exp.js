const fs=require('fs');
const D=JSON.parse(fs.readFileSync(__dirname+'/data.json','utf8'));
const HTML=fs.readFileSync(__dirname+'/../dashboard/golf-analysis-es.html','utf8');
// Funciones REALES del dashboard (tras el cambio del 10-oct-2026, que ya implementa la variante V3),
// extraídas por marcadores de texto (no por nº de línea) y ejecutadas sobre los mismos datos.
const meanSrc = HTML.slice(HTML.indexOf('function mean(arr)'), HTML.indexOf('\n', HTML.indexOf('function mean(arr)')));
const poolSrc = HTML.slice(HTML.indexOf('let HOLE_MODEL = null;'), HTML.indexOf('// Same signed-severity scale'));
const real = new Function('DATA', meanSrc+'\n'+poolSrc+'\nreturn {computeHoleExpectedAgg};')(D);
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;

// ratings from the dashboard
const CR={'Altea Club de Golf':[70.1,127],'Campo De Golf Parador Del Saler':[72.7,133],'Club de Golf Ifach':[58.8,109],'Club de Golf Jávea':[69.8,128],'Font del Llop Golf Resort':[71.6,140],'Golf La Finca':[72.7,133],'La Galiana Campo de Golf':[71.8,146],'La Sella Gregal':[72.0,131],'La Sella Llebeig':[73.4,140],'La Sella Mestral':[70.2,126],'Oliva Nova Golf Club':[70.7,135],'Puig Campana Golf Course':[70.6,121]};

// --- SI normalisation to a common 1-9 scale
function normSI(holes){
  const out=holes.map(h=>({...h}));
  const byR={};
  out.forEach(h=>(byR[h.r]=byR[h.r]||[]).push(h));
  Object.entries(byR).forEach(([r,hs])=>{
    const nh=D.rounds[r].nh;
    if(nh===9){ hs.slice().sort((a,b)=>a.si-b.si).forEach((h,i)=>h.si=i+1); }
    else { hs.forEach(h=>h.si=Math.ceil(h.si/2)); }
  });
  return out;
}
// --- per-hole course offset (strokes over par per hole for a player of index HI)
function offsets(HI){
  const o={}; 
  Object.keys(CR).forEach(c=>{
    const hs=D.holes.filter(h=>h.rc===c); const pbar=mean(hs.map(h=>h.p));
    const [cr,sl]=CR[c];
    o[c]={perHole:(HI*sl/113+(cr-18*pbar))/18, par18:18*pbar, cr, sl};
  });
  return o;
}
// --- generic agg with optional offsets
function aggWith(holes, offF){ return agg(holes, null, offF); }
function agg(holes, off, offF){
  const offOf = h => offF? offF(h) : (off? off[h.rc].perHole : 0);
  const adj = h => h.g - offOf(h);
  const byPS={}, byP={};
  holes.forEach(h=>{const e={k:h.rc+'|'+h.rh,g:adj(h)};(byPS[h.p+'|'+h.si]=byPS[h.p+'|'+h.si]||[]).push(e);(byP[h.p]=byP[h.p]||[]).push(e);});
  const groups={};
  holes.forEach(h=>{const k=h.rc+'|'+h.rh;(groups[k]=groups[k]||{rc:h.rc,rh:h.rh,p:h.p,items:[]}).items.push(h);});
  const resid=[]; // instance level
  const res=Object.values(groups).map(g=>{
    const k=g.rc+'|'+g.rh;
    const ex=g.items.map(h=>{
      const a=(byPS[h.p+'|'+h.si]||[]).filter(x=>x.k!==k), pa=(byP[h.p]||[]).filter(x=>x.k!==k);
      const lm=a.length?mean(a.map(x=>x.g)):null, pm=pa.length?mean(pa.map(x=>x.g)):null;
      if(lm===null&&pm===null) return null;
      const w=a.length/(a.length+10);
      let e=w*(lm===null?pm:lm)+(1-w)*(pm===null?lm:pm);
      e+=offOf(h);
      resid.push({rc:h.rc,r:h.r,res:h.g-e});
      return e;
    }).filter(v=>v!==null);
    const avg=mean(g.items.map(h=>h.g));
    return {key:k,rc:g.rc,rh:g.rh,par:g.p,times:g.items.length,avg,expected:mean(ex),vs:avg-mean(ex)};
  });
  return {res,resid};
}
// sanity: la réplica V3 (SI común + offset hcp/18 de la ronda) debe coincidir con la función del dashboard
function sanityV3(){
  const H1s=normSI(D.holes); const offH=h=>D.rounds[h.r].hcp/18;
  const mine=agg(H1s,null); // (se rellena abajo con offH)
  const custom=aggWith(H1s,offH).res.filter(r=>r.times>=3);
  const dash=real.computeHoleExpectedAgg(D.holes).filter(r=>r.times>=3);
  let maxd=0; dash.forEach(r=>{const m=custom.find(x=>x.key===r.rc+'|'+r.rh); maxd=Math.max(maxd,Math.abs(m.vs-r.vsExpected));});
  console.log('sanity V3 réplica vs función del dashboard: hoyos',custom.length,dash.length,'max |diff| vsExpected =',maxd.toExponential(2));
}
sanityV3();
const HI=12;
const O=offsets(HI), O0=offsets(0);
console.log('\nOffset por campo (HI=12), golpes por hoyo / por 18:');
Object.entries(O).sort((a,b)=>b[1].perHole-a[1].perHole).forEach(([c,v])=>console.log(c.padEnd(34),'CR',v.cr,'slope',v.sl,'par18',v.par18.toFixed(0),'->',v.perHole.toFixed(3),'/hoyo',(v.perHole*18).toFixed(1),'/18   (solo CR-par: '+((O0[c].perHole*18).toFixed(1))+')'));

const H1=normSI(D.holes);
const V={ V0:agg(D.holes,null), V1:agg(H1,null), V2:agg(H1,O), V2b:agg(D.holes,O) };
const out={};
for(const [n,v] of Object.entries(V)){
  const list=v.res.filter(r=>r.times>=3);
  out[n]={list, worst:list.slice().sort((a,b)=>b.vs-a.vs).slice(0,10), best:list.slice().sort((a,b)=>a.vs-b.vs).slice(0,8)};
}
const lab=r=>r.key.replace('Club de Golf ','').replace('Golf Club','').replace('Altea Club de Golf','Altea')+' h'+r.rh;
for(const n of ['V0','V1','V2']){
  console.log('\n=== '+n+(n==='V0'?' (actual)':n==='V1'?' (SI en escala común)':' (SI común + offset de campo)')+' ===');
  console.log('PEORES:',out[n].worst.map(r=>lab(r)+' '+r.vs.toFixed(2)).join(' | '));
  console.log('MEJORES:',out[n].best.map(r=>lab(r)+' '+r.vs.toFixed(2)).join(' | '));
}
const ov=(a,b,k)=>out[a][k].filter(x=>out[b][k].some(y=>y.key===x.key)).length;
console.log('\nSolapamiento top10 peores  V0-V1:',ov('V0','V1','worst'),'/10  V0-V2:',ov('V0','V2','worst'),'/10  V1-V2:',ov('V1','V2','worst'),'/10');
console.log('Solapamiento top8 mejores  V0-V1:',ov('V0','V1','best'),'/8   V0-V2:',ov('V0','V2','best'),'/8   V1-V2:',ov('V1','V2','best'),'/8');
// rank correlation
function rank(a){const s=a.map((v,i)=>[v,i]).sort((x,y)=>x[0]-y[0]);const r=[];s.forEach((p,i)=>r[p[1]]=i);return r;}
function pear(x,y){const mx=mean(x),my=mean(y);let n=0,dx=0,dy=0;x.forEach((v,i)=>{n+=(v-mx)*(y[i]-my);dx+=(v-mx)**2;dy+=(y[i]-my)**2;});return n/Math.sqrt(dx*dy);}
function spear(a,b){const keys=a.list.map(r=>r.key);const x=a.list.map(r=>r.vs),y=keys.map(k=>b.list.find(r=>r.key===k).vs);return pear(rank(x),rank(y));}
console.log('Spearman vsExpected entre variantes (hoyos con >=3 visitas, n='+out.V0.list.length+'):  V0-V1',spear(out.V0,out.V1).toFixed(3),' V0-V2',spear(out.V0,out.V2).toFixed(3));
// course-level contamination
console.log('\nResidual medio por campo (media de g - esperado sobre TODAS las instancias; >0 = peor de lo esperado)');
const courses=Object.keys(CR);
const rows=courses.map(c=>{const nR=new Set(D.holes.filter(h=>h.rc===c).map(h=>h.r)).size; const row={c,nR,off:O[c].perHole}; for(const n of ['V0','V1','V2']){row[n]=mean(V[n].resid.filter(x=>x.rc===c).map(x=>x.res));} return row;});
rows.sort((a,b)=>b.off-a.off).forEach(r=>console.log(r.c.padEnd(34),('rondas '+r.nR).padEnd(10),'offset',r.off.toFixed(2).padStart(6),' V0',r.V0.toFixed(2).padStart(6),' V1',r.V1.toFixed(2).padStart(6),' V2',r.V2.toFixed(2).padStart(6)));
const sd=a=>{const m=mean(a);return Math.sqrt(mean(a.map(v=>(v-m)**2)));};
console.log('Dispersión (DE) del residual medio entre campos:  V0',sd(rows.map(r=>r.V0)).toFixed(3),' V1',sd(rows.map(r=>r.V1)).toFixed(3),' V2',sd(rows.map(r=>r.V2)).toFixed(3));
console.log('Correlación residual-campo vs offset oficial:    V0',pear(rows.map(r=>r.V0),rows.map(r=>r.off)).toFixed(2),' V1',pear(rows.map(r=>r.V1),rows.map(r=>r.off)).toFixed(2),' V2',pear(rows.map(r=>r.V2),rows.map(r=>r.off)).toFixed(2));
// movements in worst list: V0 -> V2 per hole
console.log('\nCambios de V0 a V2 (hoyos que entran/salen del top10 peores):');
console.log(' salen:',out.V0.worst.filter(x=>!out.V2.worst.some(y=>y.key===x.key)).map(lab).join(', ')||'-');
console.log(' entran:',out.V2.worst.filter(x=>!out.V0.worst.some(y=>y.key===x.key)).map(lab).join(', ')||'-');
console.log('Cambios mejores: salen:',out.V0.best.filter(x=>!out.V2.best.some(y=>y.key===x.key)).map(lab).join(', ')||'-',' | entran:',out.V2.best.filter(x=>!out.V0.best.some(y=>y.key===x.key)).map(lab).join(', ')||'-');
