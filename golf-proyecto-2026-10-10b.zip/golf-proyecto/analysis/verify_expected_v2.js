const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const out = {};
  for (const [label, vp] of [['desktop',{width:1400,height:900}],['mobile',{width:390,height:800}]]) {
    const page = await browser.newPage({ viewport: vp });
    const errs = [];
    page.on('pageerror', e => errs.push('PAGEERROR '+e.message));
    page.on('console', m => { if (m.type()==='error' && !/ERR_TUNNEL_CONNECTION_FAILED|ERR_/.test(m.text())) errs.push('CONSOLE '+m.text()); });
    await page.goto('file://'+require('path').resolve(__dirname,'../dashboard/golf-analysis-es.html'));
    await page.waitForTimeout(800);
    const tabs = ['overview','detailed','rounds','holes','clubs','courses'];
    for (const t of tabs) {
      await page.click(`[data-tab="${t}"]`);
      await page.waitForTimeout(250);
    }
    await page.click('[data-tab="holes"]'); await page.waitForTimeout(300);
    const rows = async id => page.$$eval(`#${id} tr`, trs => trs.map(tr => [...tr.querySelectorAll('td')].map(td => td.textContent.trim())));
    if (label==='desktop') {
      out.worst = (await rows('holesBody')).map(r => r.slice(0,9));
      out.best = (await rows('bestHolesBody')).map(r => r.slice(0,9));
      // courses tab: pick the first course row and read the hole table
      await page.click('[data-tab="courses"]'); await page.waitForTimeout(300);
      out.courseTableRows = await page.$$eval('#courseHoleBody tr', trs => trs.length).catch(()=>null);
      // rounds tab: select a round and read vs expected column presence
      await page.click('[data-tab="rounds"]'); await page.waitForTimeout(300);
      out.roundHoleRows = await page.$$eval('#roundHoleBody tr', trs => trs.length).catch(()=>null);
    }
    out['errors_'+label] = errs;
    await page.close();
  }
  await browser.close();
  console.log(JSON.stringify(out,null,1));
})();
