const fs=require('fs');
const D=JSON.parse(fs.readFileSync(__dirname+'/data.json','utf8'));
const mean=a=>a.reduce((x,y)=>x+y,0)/a.length;
function normSI(holes){const out=holes.map(h=>({...h}));const byR={};out.forEach(h=>(byR[h.r]=byR[h.r]||[]).push(h));
 Object.entries(byR).forEach(([r,hs])=>{if(D.rounds[r].nh===9){hs.slice().sort((a,b)=>a.si-b.si).forEach((h,i)=>h.si=i+1);}else hs.forEach(h=>h.si=Math.ceil(h.si/2));});return out;}
const CR={'Altea Club de Golf':[70.1,127],'Campo De Golf Parador Del Saler':[72.7,133],'Club de Golf Ifach':[58.8,109],'Club de Golf Jávea':[69.8,128],'Font del Llop Golf Resort':[71.6,140],'Golf La Finca':[72.7,133],'La Galiana Campo de Golf':[71.8,146],'La Sella Gregal':[72.0,131],'La Sella Llebeig':[73.4,140],'La Sella Mestral':[70.2,126],'Oliva Nova Golf Club':[70.7,135],'Puig Campana Golf Course':[70.6,121]};
// offset functions return strokes/hole for a hole instance
const offCourse=(HI)=>{const o={};Object.keys(CR).forEach(c=>{const hs=D.holes.filter(h=>h.rc===c);const pb=mean(hs.map(h=>h.p));o[c]=(HI*CR[c][1]/113+(CR[c][0]-18*pb))/18;});return h=>o[h.rc];};
const offRoundHcp=h=>D.rounds[h.r].hcp/18;
function agg(holes,offF){
  const adj=h=>offF?h.g-offF(h):h.g;
  const byPS={},byP={};
  holes.forEach(h=>{const e={k:h.rc+'|'+h.rh,g:adj(h)};(byPS[h.p+'|'+h.si]=byPS[h.p+'|'+h.si]||[]).push(e);(byP[h.p]=byP[h.p]||[]).push(e);});
  const groups={};holes.forEach(h=>{const k=h.rc+'|'+h.rh;(groups[k]=groups[k]||{rc:h.rc,rh:h.rh,items:[]}).items.push(h);});
  const resid=[];
  const res=Object.values(groups).map(g=>{const k=g.rc+'|'+g.rh;
    const ex=g.items.map(h=>{const a=byPS[h.p+'|'+h.si].filter(x=>x.k!==k),pa=byP[h.p].filter(x=>x.k!==k);
      const lm=a.length?mean(a.map(x=>x.g)):null,pm=pa.length?mean(pa.map(x=>x.g)):null;if(lm===null&&pm===null)return null;
      const w=a.length/(a.length+10);let e=w*(lm===null?pm:lm)+(1-w)*(pm===null?lm:pm);if(offF)e+=offF(h);
      resid.push({rc:h.rc,r:h.r,res:h.g-e});return e;}).filter(v=>v!==null);
    const avg=mean(g.items.map(h=>h.g));return {key:g.rc+'|'+g.rh,rc:g.rc,rh:g.rh,times:g.items.length,vs:avg-mean(ex)};});
  return {res,resid};}
const H1=normSI(D.holes);
const V={V0:agg(D.holes,null),V2:agg(H1,offCourse(12)),V3:agg(H1,offRoundHcp)};
const out={};for(const [n,v] of Object.entries(V)){const l=v.res.filter(r=>r.times>=3);out[n]={l,worst:l.slice().sort((a,b)=>b.vs-a.vs).slice(0,10),best:l.slice().sort((a,b)=>a.vs-b.vs).slice(0,8)};}
const lab=r=>r.key.replace('Club de Golf ','').replace(' Golf Club','').replace('Altea Club de Golf','Altea').replace('|',' h');
for(const n of ['V3']){console.log('V3 PEORES:',out[n].worst.map(r=>lab(r)+' '+r.vs.toFixed(2)).join(' | '));console.log('V3 MEJORES:',out[n].best.map(r=>lab(r)+' '+r.vs.toFixed(2)).join(' | '));}
const ov=(a,b,k)=>out[a][k].filter(x=>out[b][k].some(y=>y.key===x.key)).length;
console.log('Solape V0-V3 peores',ov('V0','V3','worst'),'/10, mejores',ov('V0','V3','best'),'/8;  V2-V3 peores',ov('V2','V3','worst'),'/10 mejores',ov('V2','V3','best'),'/8');
// residual by half-year (round date), all variants
console.log('\nResidual medio por semestre (>0 = peor de lo esperado)   n=hoyos');
const half=r=>{const d=D.rounds[r].d;return d.slice(0,4)+(+d.slice(5,7)<=6?'H1':'H2');};
const hs=[...new Set(D.rounds.map((_,i)=>half(i)))].sort();
hs.forEach(p=>{const row=[p];for(const n of ['V0','V2','V3']){const x=V[n].resid.filter(q=>half(q.r)===p);row.push(n+' '+mean(x.map(q=>q.res)).toFixed(2).padStart(5));row.n=x.length;}console.log(row.join('  '),' n='+row.n);});
// time trend of hcp
console.log('\nhcp (hándicap de campo) por ronda, media por semestre:');
hs.forEach(p=>{const rr=D.rounds.map((r,i)=>({r,i})).filter(o=>half(o.i)===p);console.log(p,mean(rr.map(o=>o.r.hcp)).toFixed(1),'(rondas',rr.length+')');});
